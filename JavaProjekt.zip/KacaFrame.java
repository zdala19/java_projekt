import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.*;
import javax.swing.*;
import imageio;
 


public class KacaFrame {

    public KacaFrame(){

        JFrame frame = new JFrame();
        KacaPanel kacapanel = new KacaPanel();

        frame.add(kacapanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //če pritisnemo na križec se okno zapre
        frame.getRootPane().putClientProperty("apple.awt.brushMetalLook", true);
        frame.setResizable(false);
        frame.setTitle("Kača");
        frame.pack();
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);
        frame.setLocationRelativeTo(null); //okno se odpre na sredini ekrana
    }
    public static void main(String[] args) {
        new KacaFrame();
    }
}
