import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.awt.event.ActionListener;
import java.util.Random.nextInt;

import javax.swing.*;




public class KacaPanel extends JPanel implements ActionListener{

    static final int sirina_okna = 500, dolzina_okna = 500;
    static final int velikost_delca = 20;
    static final int velikost_kvadratka = (sirina_okna * dolzina_okna) / velikost_delca;
    static final int hitrost = 100;
    static final int stevilo_kvadratkov_v_vrstici = sirina_okna / velikost_delca;
    static final int stevilo_kvadratkov_v_stolpcu = dolzina_okna / velikost_delca;
    
    final int x[] = new int[velikost_kvadratka];
    final int y[] = new int[velikost_kvadratka];
    int stevilo_pobranih_kovanckov = 0;
    int dolzina_telesa = 5;
    int kovancekX;
    int kovancekY;

    boolean running = true;
    Timer timer;
    Random random;
    
    
    private boolean Levo = false;
	private boolean Desno = true;
	private boolean Gor = false;
	private boolean Dol = false;
    


    KacaPanel(){
        random = new Random();
        this.setPreferredSize(new Dimension(sirina_okna, dolzina_okna));
        this.setBackground(new Color(217,242,250));
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
        start();
    }

    public void start() {
        novKovancek(); //narišemo prvi kovanček
        running = true;
        timer = new Timer(hitrost, this);
        timer.start();
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g){
        if (running) {
            g.setColor(new Color(255, 225, 0));
            g.fillOval(kovancekX, kovancekY, velikost_delca, velikost_delca);

            for (int index = 0; index < dolzina_telesa; index = index + 1){
                if(index == 0){
                    g.setColor(Color.BLACK);
                    g.fillRect(x[index], y[index], velikost_delca, velikost_delca);
                }
                else {
                    g.setColor(new Color(217, random.nextInt(255), 217));
                    g.fillRect(x[index], y[index], velikost_delca, velikost_delca);
                }
            }
            g.setColor(Color.black);
            g.setFont(new Font("SansSerif", Font.BOLD, 15));
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("Točke: " + stevilo_pobranih_kovanckov, 3,15);
            g.drawString("Dolžina: " + dolzina_telesa, 3,35);
        }
        else {
            konecIgre(g);
        }
    }
    
    public void novKovancek(){
        kovancekX = random.nextInt(stevilo_kvadratkov_v_vrstici) * velikost_delca;
        kovancekY = random.nextInt(stevilo_kvadratkov_v_stolpcu) * velikost_delca;
    }

    public void premik(){
        for (int i = dolzina_telesa; i > 0; i = i - 1){
            x[i] = x[i-1];
            y[i] = y[i-1];
        }
        if (Levo){
            x[0] = x[0] - velikost_delca;
        }
        if(Desno){
            x[0] = x[0] + velikost_delca;
        }
        if (Gor){
            y[0] = y[0] + velikost_delca;
        }
        if (Dol){
            y[0] = y[0] - velikost_delca;
        }   
    }

    public void poberiKovancek(){
        if (x[0] == kovancekX){
            if (y[0] == kovancekY){
                dolzina_telesa = dolzina_telesa + 1;
                stevilo_pobranih_kovanckov = stevilo_pobranih_kovanckov + 1;
                novKovancek();
            }
        }

    }

    public void checkCollisions(){

        for (int k = dolzina_telesa; k > 0; k = k - 1 ) {
            if(x[0] == x[k]){
                if (y[0] == y[k]){
                    running = false;
                }
            }
        }
        
    
        //preverimo, če se kača zaleti v rob našega okna 
        if (x[0] < 0) {
            running = false;
        }
        if (x[0] > sirina_okna){
            running = false;
        }
        if (y[0] < 0){
            running = false;
        }
        if (y[0] > dolzina_okna){
            running = false;
        }

        if (running == false) {
            timer.stop();
        }

    }


    public void konecIgre(Graphics g) {
        g.setColor(Color.black);
        g.setFont(new Font("SansSerif", Font.BOLD, 67));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString("Konec igre", (sirina_okna - metrics.stringWidth("KonecIgre"))/2, sirina_okna / 2);

    }
    @Override
    public void actionPerformed(ActionEvent e){
        if (running) {
            premik();
            poberiKovancek();
            checkCollisions();
        }
        repaint();
    }
    

    public class MyKeyAdapter extends KeyAdapter{
        @Override
        public void keyPressed(KeyEvent e){

            switch(e.getKeyCode()){

            case KeyEvent.VK_SPACE:
                stevilo_pobranih_kovanckov = 0;
                dolzina_telesa = 5;
                repaint();

            case KeyEvent.VK_LEFT:
                if(Desno == false){
                    Levo = true;
                    Dol = false;
                    Gor = false;
                }
                break;

            
            case KeyEvent.VK_RIGHT:
                if(Levo == false){
                    Desno = true;
                    Gor = false;
                    Dol= false;
                }
                break;

            case KeyEvent.VK_DOWN:
                if(Dol == false){
                    Levo = false;
                    Desno = false;
                    Gor = true;
                }
                break;
            
            case KeyEvent.VK_UP:
                if(Gor == false){
                    Levo = false;
                    Desno = false;
                    Dol = true;
                }
                break;
            }

        }

    }

}
